HOW TO INSTALL
1) Drop the 'pages' and 'asset' folders into the ROOT of your website repo.
2) Copy your exported GLBs into 'asset/models/out/' and their PNG thumbnails into 'asset/models/thumbs/'.
3) Visit pages/reyczar.html and pages/whitestar.html once deployed.

BLENDER BATCH MANIFEST ADDITIONS
- See 'manifest_additions.csv' and append those lines to C:\Projects\Wings_vrm\manifest.csv
